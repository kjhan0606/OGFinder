ds10-web reproducibility bundle

session.json   the recorded events (hash-chained)
manifest.json  inputs, outputs, tool versions, licence-policy tags
params.json    parameters and command-line templates per job
plugins/       parameter manifests of the tools used
methods.txt    methods summary
replay.py      runnable replay + comparison (python3 replay.py list | check-bundle | local | server)
checksums.sha256  SHA-256 of every other file
data/         data products of the recorded jobs; inputs/ the images handed to the tools
offline/       offline.json, session_script.json, files/ (the images), README_OFFLINE.txt: open it with 'ds10 open'
