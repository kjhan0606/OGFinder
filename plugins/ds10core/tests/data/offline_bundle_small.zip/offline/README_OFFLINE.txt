ds10 offline bundle - session "fixture session" (34b9dee6b7d1e35a), 5 recorded events, made 2026-10-05 06:25:52 KST by ds10-web 0.1.0

WHAT THIS IS
  A snapshot of your web session that you can continue on your own computer with the stand-alone ds10 program (no network, no server).

HOW TO CONTINUE
  python -m ds10core open THIS_FILE.zip --dest my-session        (from the ds10-web server directory; OGFinder: scripts/ds10 open ...)
  OGFinder GUI: menu ds10core > Open offline bundle...
  Then edit my-session/session_script.json (add steps at the end) and run it:
  python -m ds10core run my-session/session_script.json      (steps that did not change use the stored results; new steps are run)

WHAT IS IN IT
  1 image file(s): field96.fits (original)
  1 finished job(s) with their results, the regions (1), the parameters and checksums of everything.
  Every file is listed with its SHA-256 in checksums.sha256; 'open' checks them first.

WHAT IT CANNOT DO
  - The bundle is a snapshot: work done on the server after it was made is not in it.
  - Only what ds10core can run on this computer works offline: the built-in tools (detect, detection image, forced photometry) and the stand-alone tools of the OGFinder collection; tools that need other programs (for example SExtractor, PSFEx) need those programs installed.
  - Results are bit-identical to the server's only with the same Python, numpy and scipy versions; otherwise they agree within rounding (use 'ds10 compare').
  - Regions drawn in the browser are restored as a DS9 region file; the stand-alone GUI shows them in ds9.
  - The browser cannot start the stand-alone program, and the stand-alone program cannot reach the server: moving the work back is an upload of a return bundle.

ABOUT THE SCRIPT
  - every finished job of the session is a step of the script.
